"use client";

export default function GhostInput({
  text,
  suggestion,
  onChange,
  onKeyDown
}) {

  const remaining =
    suggestion.startsWith(text)
      ? suggestion.slice(text.length)
      : "";

  return (
    <div className="input-wrapper">
      <div className="ghost-text">
        <span className="typed">{text}</span>
        <span className="ghost">{remaining}</span>
      </div>

      <input
        className="typing-input"
        value={text}
        onChange={onChange}
        onKeyDown={onKeyDown}
      />
    </div>
  );
}

/*"use client";

export default function GhostInput({
  text,
  suggestion,
  setText,
  onKeyDown,
  targetWord,
  addKeystroke
}) {

  const ghostPart =
    suggestion && suggestion.startsWith(text)
      ? suggestion.slice(text.length)
      : "";

  const renderLetters = () => {

    if (!targetWord) return null;

    return targetWord.split("").map((char, index) => {

      let color = "#64748b"; // default gray

      if (index < text.length) {
        color = text[index] === char ? "#22c55e" : "#ef4444";
      }

      return (
        <span key={index} style={{ color }}>
          {char}
        </span>
      );
    });
  };

  return (
    <div className="typing-box">

      <input
        className="typing-input"
        value={text}
        onChange={(e) => {
          //startTyping();
          setText(e.target.value);
        }}
        onKeyDown={(e) => {
          addKeystroke();   // ✅ track every key
          onKeyDown(e);     // existing logic
        }}
        autoFocus
      />

      <div className="target-word">
        {renderLetters()}
      </div>

      <div className="ghost-text">
        {text}
        <span className="ghost">{ghostPart}</span>
      </div>

    </div>
  );
} */