"use client";

import { useMemo } from "react";

const chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";

export default function FloatingChaos({ intensity }) {

  const items = useMemo(() => {
    return Array.from({ length: intensity }).map(() => ({
      char: chars[Math.floor(Math.random() * chars.length)],
      top: Math.random() * 200,
      left: Math.random() * 500
    }));
  }, [intensity]);

  return (
    <div className="chaos-layer">
      {items.map((item, i) => (
        <span
          key={i}
          className="chaos-letter"
          style={{
            top: item.top,
            left: item.left
          }}
        >
          {item.char}
        </span>
      ))}
    </div>
  );
}

/*import { useEffect, useState } from "react";

export default function FloatingChaos({ active }) {

  const [items, setItems] = useState([]);

  useEffect(() => {
    if (active) {
      const chars = ["@", "#", "%", "&", "?", "!", "$"];

      const newItems = chars.map((char) => ({
        char,
        top: 40 + Math.random() * 120,
        left: 50 + Math.random() * 500,
        color: `hsl(${Math.random() * 360}, 80%, 60%)`
      }));

      setItems(newItems);
    }
  }, [active]);

  if (!active) return null;

  return (
    <div className="chaos-layer">
      {items.map((item, i) => (
        <span
          key={i}
          className="chaos-item"
          style={{
            top: item.top,
            left: item.left,
            color: item.color
          }}
        >
          {item.char}
        </span>
      ))}
    </div>
  );
}*/