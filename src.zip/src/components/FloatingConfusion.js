"use client";

import { useMemo } from "react";

export default function FloatingConfusion({ words }) {

  const items = useMemo(() => {
    return words.map((word, i) => ({
      word,
      top: 20 + Math.random() * 40,   // closer vertically
      left: 20 + Math.random() * 60   // stays near input
    }));
  }, [words]);

  return (
    <div className="confusion-layer">
      {items.map((item, i) => (
        <span
          key={i}
          className="confusion-item"
          style={{
            top: `${item.top}%`,
            left: `${item.left}%`
          }}
        >
          {item.word}
        </span>
      ))}
    </div>
  );
}

/*"use client";

export default function FloatingConfusion({ words }) {

  return (
    <div className="confusion-layer">
      {words.map((word, i) => (
        <span
          key={i}
          className="confusion-item"
          style={{
            left: `${20 + Math.random() * 80}%`,
            animationDelay: `${i * 0.2}s`
          }}
        >
          {word}
        </span>
      ))}
    </div>
  );
}*/