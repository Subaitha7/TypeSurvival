"use client";

import { useState, useRef, useEffect, useMemo } from "react";
import generateSentence from "@/lib/generateSentence";
import getConfusingWords from "@/lib/getConfusingWords";
import useTypingMetrics from "@/hooks/useTypingMetrics";
import GhostInput from "@/components/GhostInput";
import Leaderboard from "../components/Leaderboard";
import FloatingConfusion from "@/components/FloatingConfusion";
import FloatingChaos from "@/components/FloatingChaos";
import trie from "@/lib/trieClient";
import words from "@/lib/words.json";

export default function Page() {
  const [sentence, setSentence] = useState([]);
  const [index, setIndex] = useState(0);
  const [difficulty, setDifficulty] = useState("medium");
  const inputRef = useRef("");
  const [, forceUpdate] = useState(0);

  const {
    wpm,
    accuracy,
    kspc,
    startTyping,
    addKeystroke,
    addCorrectChar,
    addWrongChar
  } = useTypingMetrics();
  
  const heatMode = wpm >= 10 && wpm < 20;
  const chaosMode = wpm >= 20;

  useEffect(() => {
    setSentence(generateSentence(10, difficulty));
  }, []);

  const currentWord = sentence[index] || "";

  const handleChange = (e) => {
    const value = e.target.value;

    inputRef.current = value;
    forceUpdate((n) => n + 1);

    startTyping();
    addKeystroke();

    const expected = currentWord[value.length - 1];

    if (value[value.length - 1] === expected) {
      addCorrectChar();
    } else {
      addWrongChar();
    }
  };

  const handleKeyDown = (e) => {
    if (e.key === " ") {
      e.preventDefault();

      if (index < sentence.length - 1) {
        setIndex((i) => i + 1);
      } else {
        setSentence(generateSentence(10, difficulty));
        setIndex(0);
      }

      inputRef.current = "";
      forceUpdate((n) => n + 1);
    }
  };

  const resetSession = () => {
    setSentence(generateSentence(10, difficulty));
    setCurrentWordIndex(0);
    setText("");
    resetMetrics();
  };

  const handleFinish = async () => {
    const survivalScore = wpm * accuracy;

    await saveSession({
      wpm,
      accuracy,
      kspc,
      survivalScore
    });

    resetSession();
  };

  const suggestions = useMemo(() => {
    if (!inputRef.current) return [];
    return trie.getSuggestions(inputRef.current, 3);
  }, [inputRef.current]);

  const confusingWords = useMemo(() => {
    return getConfusingWords(currentWord, words);
  }, [currentWord]);

  // ✅ FIX: cache ref before render
  const typedText = inputRef.current;

  return (
    <div className={`container 
      ${heatMode ? "heat-mode" : ""} 
      ${chaosMode ? "chaos-mode" : ""}
    `}>

      <h1 className="title">TypeSurvival ⚡</h1>
      <p className="subtitle">
        The typing test that fights back
      </p>

      <div className="game-card">

        {/* 🔥 SENTENCE WITH CHARACTER FEEDBACK */}
        <div className="sentence-box">
          {sentence.map((word, i) => {
            if (i !== index) {
              return (
                <span key={i} className="word">
                  {word}
                </span>
              );
            }

            return (
              <span key={i} className="word active">
                {word.split("").map((char, charIndex) => {
                  const typedChar = typedText[charIndex];

                  let className = "char";

                  if (typedChar != null) {
                    className =
                      typedChar === char
                        ? "char correct"
                        : "char wrong";
                  }

                  return (
                    <span key={charIndex} className={className}>
                      {char}
                    </span>
                  );
                })}
              </span>
            );
          })}
        </div>

        {/* INPUT */}
        <div className="typing-box">
          <GhostInput
            text={typedText}
            suggestion={suggestions[0] || ""}
            onChange={handleChange}
            onKeyDown={handleKeyDown}
          />

          {(heatMode || chaosMode) && (
            <FloatingConfusion words={confusingWords} />
          )}

          <FloatingChaos
            intensity={
              chaosMode ? 12 :
              heatMode ? 5 :
              0
            }
          />
        </div>

        {/* 📊 STATS (FIXED) */}
        <div className="stats-box">
          <div className="stat">
            <div className="stat-value">{wpm}</div>
            <div className="stat-label">WPM</div>
          </div>

          <div className="stat">
            <div className="stat-value">{accuracy}%</div>
            <div className="stat-label">Accuracy</div>
          </div>

          <div className="stat">
            <div className="stat-value">{kspc}</div>
            <div className="stat-label">KSPC</div>
          </div>
        </div>

        <button className="finish-btn" onClick={handleFinish}>
          Finish Session
        </button>
      </div>

      <div className="leaderboard">
        <Leaderboard />
      </div>

    </div>
  );
}


/*"use client";

import { useState, useRef, useEffect, useMemo } from "react";
import generateSentence from "@/lib/generateSentence";
import getConfusingWords from "@/lib/getConfusingWords";
import useTypingMetrics from "@/hooks/useTypingMetrics";
import GhostInput from "@/components/GhostInput";
import Leaderboard from "../components/Leaderboard";
import FloatingConfusion from "@/components/FloatingConfusion";
import FloatingChaos from "@/components/FloatingChaos";
import trie from "@/lib/trieClient";
import words from "@/lib/words.json";

export default function Page() {
  const [sentence, setSentence] = useState([]);
  const [index, setIndex] = useState(0);
  const [difficulty, setDifficulty] = useState("medium");
  const inputRef = useRef("");
  const [, forceUpdate] = useState(0);

  const {
    wpm,
    accuracy,
    kspc, // ✅ RESTORED
    startTyping,
    addKeystroke,
    addCorrectChar,
    addWrongChar
  } = useTypingMetrics();

  const heatMode = wpm >= 10 && wpm < 20;
  const chaosMode = wpm >= 20;


  useEffect(() => {
    setSentence(generateSentence(10, difficulty));
  }, []);

  const currentWord = sentence[index] || "";

  // ⚡ FAST INPUT (NO LAG)
  const handleChange = (e) => {
    const value = e.target.value;

    inputRef.current = value;
    forceUpdate((n) => n + 1);

    startTyping();
    addKeystroke();

    const expected = currentWord[value.length - 1];

    if (value[value.length - 1] === expected) {
      addCorrectChar();
    } else {
      addWrongChar();
    }
  };

  const handleKeyDown = (e) => {
    if (e.key === " ") {
      e.preventDefault();

      if (index < sentence.length - 1) {
        setIndex((i) => i + 1);
      } else {
        setSentence(generateSentence(10, difficulty));
        setIndex(0);
      }

      inputRef.current = "";
      forceUpdate((n) => n + 1);
    }
  };

  const resetSession = () => {
    setSentence(generateSentence(10, difficulty));
    setCurrentWordIndex(0);
    setText("");
    resetMetrics();
  };

  const handleFinish = async () => {
    const survivalScore = wpm * accuracy;

    await saveSession({
      wpm,
      accuracy,
      kspc,
      survivalScore
    });

    resetSession();
  };


  // ✅ Trie Autocomplete
  const suggestions = useMemo(() => {
    if (!inputRef.current) return [];
    return trie.getSuggestions(inputRef.current, 3);
  }, [inputRef.current]);

  const confusingWords = useMemo(() => {
    return getConfusingWords(currentWord, words);
  }, [currentWord]);

  return (
    <div className={`container 
      ${heatMode ? "heat-mode" : ""} 
      ${chaosMode ? "chaos-mode" : ""}
    `}>

      <h1 className="title">TypeSurvival ⚡</h1>
      <p className="subtitle">
        The typing test that fights back
      </p>

      <div className="game-card">

        //🔥 SENTENCE WITH CHARACTER FEEDBACK
        <div className="sentence-box">
          {sentence.map((word, i) => {
            if (i !== index) {
              return (
                <span key={i} className="word">
                  {word}
                </span>
              );
            }

            return (
              <span key={i} className="word active">
                {word.split("").map((char, charIndex) => {
                  const typedChar = inputRef.current[charIndex];

                  let className = "char";

                  if (typedChar != null) {
                    className =
                      typedChar === char
                        ? "char correct"
                        : "char wrong";
                  }

                  return (
                    <span key={charIndex} className={className}>
                      {char}
                    </span>
                  );
                })}
              </span>
            );
          )}
        </div>

        // INPUT 
        <div className="typing-box">
          <GhostInput
            text={inputRef.current}
            suggestion={suggestions[0] || ""}
            onChange={handleChange}
            onKeyDown={handleKeyDown}
          />

          {(heatMode || chaosMode) && (
            <FloatingConfusion words={confusingWords} />
          )}
          <FloatingChaos intensity={
              chaosMode ? 12 :
              heatMode ? 5 :
              0
            } />
        </div>

        //📊 STATS (FIXED) 
        <div className="stats-box">
          <div className="stat">
            <div className="stat-value">{wpm}</div>
            <div className="stat-label">WPM</div>
          </div>

          <div className="stat">
            <div className="stat-value">{accuracy}%</div>
            <div className="stat-label">Accuracy</div>
          </div>

          <div className="stat">
            <div className="stat-value">{kspc}</div>
            <div className="stat-label">KSPC</div>
          </div>
        </div>
        <button className="finish-btn" onClick={handleFinish}>
            Finish Session
        </button>
      </div>

      <div className="leaderboard">
          <Leaderboard />
      </div>

    </div>
  
  );
} 

/*"use client";

import { useState, useRef, useEffect, useMemo } from "react";
import generateSentence from "@/lib/generateSentence";
import getConfusingWords from "@/lib/getConfusingWords";
import useTypingMetrics from "@/hooks/useTypingMetrics";
import GhostInput from "@/components/GhostInput";
import FloatingConfusion from "@/components/FloatingConfusion";
import FloatingChaos from "@/components/FloatingChaos";
import { buildTrie } from "@/lib/trie";
import words from "@/lib/words.json";

export default function Page() {
  const [sentence, setSentence] = useState([]);
  const [index, setIndex] = useState(0);
  const [difficulty, setDifficulty] = useState("medium");

  const inputRef = useRef("");
  const [, forceUpdate] = useState(0); // minimal re-render trigger

  const {
    wpm,
    accuracy,
    startTyping,
    addKeystroke,
    addCorrectChar,
    addWrongChar
  } = useTypingMetrics();

  // ✅ Build Trie ONCE
  const trie = useMemo(() => buildTrie(words), []);

  useEffect(() => {
    setSentence(generateSentence(10, difficulty));
  }, []);

  const currentWord = sentence[index] || "";

  // ✅ FAST INPUT HANDLER (no lag)
  const handleChange = (e) => {
    const value = e.target.value;

    inputRef.current = value;
    forceUpdate((n) => n + 1); // minimal UI update

    startTyping();
    addKeystroke();

    const expected = currentWord[value.length - 1];

    if (value[value.length - 1] === expected) {
      addCorrectChar();
    } else {
      addWrongChar();
    }
  };

  const handleKeyDown = (e) => {
    if (e.key === " ") {
      e.preventDefault();

      if (index < sentence.length - 1) {
        setIndex((i) => i + 1);
      } else {
        // ✅ generate NEW sentence ONLY when finished
        setSentence(generateSentence(10, difficulty));
        setIndex(0);
      }

      inputRef.current = "";
      forceUpdate((n) => n + 1);
    }
  };

  // ✅ REAL AUTOCOMPLETE (Trie-based)
  const suggestions = useMemo(() => {
    return trie.getSuggestions(inputRef.current, 3);
  }, [inputRef.current]);

  const confusingWords = useMemo(() => {
    return getConfusingWords(currentWord, words);
  }, [currentWord]);

  return (
    <div className={`container ${wpm > 80 ? "burning" : ""}`}>
      <div className="game-card">

        <div className="sentence-box">
          {sentence.map((w, i) => (
            <span key={i} className={`word ${i === index ? "active" : ""}`}>
              {w}
            </span>
          ))}
        </div>

        <div className="typing-box">
          <GhostInput
            text={inputRef.current}
            suggestion={suggestions[0] || ""}
            onChange={handleChange}
            onKeyDown={handleKeyDown}
          />

          <FloatingConfusion words={confusingWords} />
          <FloatingChaos intensity={Math.floor(wpm / 20)} />
        </div>

        <div className="stats-box">
          <div className="stat">
            <div className="stat-value">{wpm}</div>
            <div className="stat-label">WPM</div>
          </div>

          <div className="stat">
            <div className="stat-value">{accuracy}%</div>
            <div className="stat-label">Accuracy</div>
          </div>
        </div>

      </div>
    </div>
  );
}*/

/*"use client";

import { useState, useEffect } from "react";
import GhostInput from "../components/GhostInput";
import useAutocomplete from "../hooks/useAutocomplete";
import useTypingMetrics from "../hooks/useTypingMetrics";
import { saveSession } from "../lib/saveSession";
import Leaderboard from "../components/Leaderboard";
import generateSentence from "../lib/generateSentence";
import words from "../lib/words.json";
import getConfusingWords from "../lib/getConfusingWords";
import FloatingConfusion from "../components/FloatingConfusion";
import FloatingChaos from "../components/FloatingChaos";
import Stat from "../components/Stat";

export default function Home() {

  const { text, setText, suggestion } = useAutocomplete();
  const { 
    wpm, 
    accuracy, 
    kspc, 
    startTyping, 
    addKeystroke, 
    addCorrectChar, 
    addWrongChar, 
    resetMetrics
  } = useTypingMetrics();

  const [sentence, setSentence] = useState([]);
  const [currentWordIndex, setCurrentWordIndex] = useState(0);

  // 🔥 Progressive modes (FIXED)
  const heatMode = wpm > 10;
  const chaosMode = wpm > 5;

  // 🎯 Difficulty (kept but controlled)
  let difficulty = "medium";
  if (wpm < 20) difficulty = "easy";
  if (wpm > 70) difficulty = "hard";

  // 🚀 Only generate on mount (NO flicker)
  useEffect(() => {
    setSentence(generateSentence(10, difficulty));
  }, []);

  const resetSession = () => {
    setSentence(generateSentence(10, difficulty));
    setCurrentWordIndex(0);
    setText("");
    resetMetrics();
  };

  const handleFinish = async () => {
    const survivalScore = wpm * accuracy;

    await saveSession({
      wpm,
      accuracy,
      kspc,
      survivalScore
    });

    resetSession();
  };

  const handleKeyDown = (e) => {

    startTyping();

    if (e.key === " ") {
      e.preventDefault();

      if (text.trim() === "") return;

      const currentWord = sentence[currentWordIndex] || "";
      const isCorrect = text === currentWord;

      document.body.classList.add(
        isCorrect ? "flash-correct" : "flash-wrong"
      );

      setTimeout(() => {
        document.body.classList.remove("flash-correct", "flash-wrong");
      }, 150);

      // ✅ FIXED accuracy logic
      const maxLen = Math.max(text.length, currentWord.length);

      for (let i = 0; i < maxLen; i++) {
        if (text[i] === currentWord[i]) {
          addCorrectChar();
        } else {
          addWrongChar();
        }
      }

      // ➡️ next word
      if (currentWordIndex < sentence.length - 1) {
        setCurrentWordIndex((i) => i + 1);
        setText("");
      } else {
        setSentence(generateSentence(10, difficulty));
        setCurrentWordIndex(0);
        setText("");
      }
    }
  };

  const currentWord = sentence[currentWordIndex] || "";

  const confusingWords = heatMode
    ? getConfusingWords(currentWord, words)
    : [];

  useEffect(() => {
    const handleKey = (e) => {
      if (e.key === "Escape") {
        resetSession();
      }
    };

    window.addEventListener("keydown", handleKey);
    return () => window.removeEventListener("keydown", handleKey);
  }, []);

  return (
    <div className="container">

      <h1 className="title">TypeSurvival ⚡</h1>
      <p className="subtitle">
        The typing test that fights back
      </p>

      <div className="game-card">

        <div className="sentence-box">
          {sentence.map((word, index) => (
            <span
              key={index}
              className={`
                word 
                ${index === currentWordIndex ? "active" : ""}
                ${chaosMode && index === currentWordIndex ? "shake" : ""}
              `}
            >
              {word}
            </span>
          ))}
        </div>

        {heatMode && confusingWords.length > 0 && (
          <FloatingConfusion words={confusingWords} />
        )}

        <div className="input-box">
          <GhostInput
            text={text}
            suggestion={suggestion}
            setText={setText}
            onKeyDown={handleKeyDown}
            targetWord={currentWord}
            addKeystroke={addKeystroke}
          />
        </div>

        {chaosMode && <FloatingChaos active={chaosMode} />}

        <div className="stats-box">
          <Stat label="WPM" value={wpm} />
          <Stat label="Accuracy" value={`${accuracy}%`} />
          <Stat label="KSPC" value={kspc} />
        </div>

        <button className="finish-btn" onClick={handleFinish}>
          Finish Session
        </button>

      </div>

      <div className="leaderboard">
        <Leaderboard />
      </div>

    </div>
  );
} */

